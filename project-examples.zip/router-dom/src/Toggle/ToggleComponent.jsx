
import { useToggle } from '../components/customHook/useToggle'
export default function ToggleComponent() {
   const [isToggled, handleToggle] = useToggle()
   
  return (
    <div>
        <button onClick={handleToggle}>Toggle</button>
        {isToggled && <h1>Toggled Component</h1>}
    </div>
  )
}
