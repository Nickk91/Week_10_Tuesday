import React from 'react'
import { useFetch } from '../customHook/useFetch'
import { Link } from 'react-router-dom'
const url = `${import.meta.env.VITE_API_URL}/shoes`
export default function Fetch() {
    const { data, loading, error} = useFetch(url)
    console.log(data)
  return (
    <div>
        <h1>Data fetching</h1>
        {loading && <p>loading .... </p>}
        {error && <p>error fetching</p>}
        {data && <div>
            {data.map(product => (
           <Link to={`/products/${product.id}`} state={{product}}  key={product.id}> <div>{product.name}</div></Link>
        ))}
            </div>}
    </div>
  )
}
