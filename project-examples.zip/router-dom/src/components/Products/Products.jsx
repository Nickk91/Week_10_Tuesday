import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { useToggle } from '../customHook/useToggle'
import { useFetch } from '../customHook/useFetch'
const url = `${import.meta.env.VITE_API_URL}/shoes`
export default function Products() {
    const [showProducts, toggleFunc] = useToggle(true)
    const { data, loading, error} = useFetch(url)
    
  return (
    <div>
        <h1>products</h1>
        <button onClick={toggleFunc}>toggle</button>
       {showProducts &&  <div>
        {data.map(product => (
           <Link to={`/products/${product.id}`} state={{product}}  key={product.id}> <div>{product.name}</div></Link>
        ))}
        <Link to='/products/new'><button>New</button></Link> 
        </div>}
    </div>
  )
}
